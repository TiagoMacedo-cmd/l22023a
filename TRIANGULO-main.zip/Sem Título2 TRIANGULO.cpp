#include <iostream>
using namespace std;
int main( ){
int lado1, lado2, lado3;
int s1, s2, s3;
cout << "Entre com o tamanho dos lados do triangulo: ";
cin >> lado1 >> lado2 >> lado3;
// calcula o quadrado dos lados
s1 = lado1*lado1;
s2 = lado2*lado2;
s3 = lado3*lado3;
// testa a condicao para um triangulo reto
if ( lado1>0 && lado2>0 && lado3 <= 50 ) {
if (s1==s2+s3 || s2==s1+s2 || s2==s1+s3) ) {
cout << "Triangulo reto!\n";
cin >> 1++ ;
}
else {
cout << "Nao pode ser um triangulo!\n";
}
}

